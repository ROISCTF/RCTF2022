#!/bin/sh
# Add your startup script
export TERM=xterm
# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;

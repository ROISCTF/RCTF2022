#ifndef WIN_H
#define WIN_H

#include <ncurses.h>                    /* ncurses.h includes stdio.h */
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

void initBoard();




#endif
#ifndef UTIL_H
#define UTIL_H


unsigned char getRandomNum();
int isSlip(int p);

#endif
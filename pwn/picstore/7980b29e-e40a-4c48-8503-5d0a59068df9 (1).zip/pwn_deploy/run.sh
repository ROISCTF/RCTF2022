docker run -d -p "0.0.0.0:5566:8888" -h "picstore" --name="picstore_use" picstore 

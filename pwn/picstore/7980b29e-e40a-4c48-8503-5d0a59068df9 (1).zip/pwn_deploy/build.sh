docker build -t "picstore" .

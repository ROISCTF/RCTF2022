#!/usr/bin/python3
from flask import Flask,request,render_template
import os
import hashlib

app_dir = os.path.split(os.path.realpath(__file__))[0]
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = f'{app_dir}/upload/'

def ip2md5(ip):
    h = hashlib.md5()
    h.update(ip.encode())
    return h.hexdigest()

@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'GET':
        return render_template('index.html',result="Welcome to RCTF2022, have fun!")
    elif request.method == 'POST':
        try:
            f = request.files['file-upload']
            # filepath = os.path.join(app.config['UPLOAD_FOLDER'], f.filename)
            # md5ip = ip2md5(request.remote_addr)
            #md5ip = ip2md5(request.args.get('ip'))
            md5ip = ip2md5(request.args.get('ip'))
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], md5ip+".js")
            f.save(filepath)
            cmd = "su ctf -c \"java FlagServer %s\" "%filepath
            print(cmd)
            res = os.popen(cmd).read()
            # print(res)
            return render_template('index.html', result=res)
        except:
            return render_template('index.html', result='error')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)

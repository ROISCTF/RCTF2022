# python.exe bb.py fledge.exe
import frida
import sys


def on_message(message, data):
    print("[%s] => %s" % (message, data))


def main(target_process, scriptname):
    session = frida.attach(target_process)
    with open(scriptname) as f:
        scriptcontent = f.read()
    script = session.create_script(scriptcontent)
    script.on('message', on_message)
    script.load()
    sys.stdin.read()
    session.detach()


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: %s <process name or PID> <jsScriptName>" % __file__)
        sys.exit(1)
    try:
        target_process = int(sys.argv[1])
    except ValueError:
        target_process = sys.argv[1]
    main(target_process, sys.argv[2])
